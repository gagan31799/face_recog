import cv2
import os
import numpy as np
import imutils
import face_recognition as fr
from imutils.video import VideoStream
import pickle


def train():
	if os.path.isfile('training_model'):
		os.remove("training_model")

	known_encoding=[]
	known_names=[]
	filenames={}
	count=1
	path1=os.getcwd()+"/photos/known"
	for root,sub_dir,files in os.walk(path1):		
		for file in files:
			filenames[file]=os.path.join(root,file)
			

	for key in filenames:		
		try:

			img=fr.load_image_file(filenames[key])
			a=fr.face_encodings(img)[0]
			known_encoding.append(a)
			known_names.append(str(key)[:-4])
		except:
			pass	
	data = {"encodings": known_encoding, "names": known_names}
	f=open("training_model","wb")
	f.write(pickle.dumps(data))
	f.close()

train()