
import face_recognition as fr
import pickle
import sys
sys.dont_write_bytecode = True

def recognize(image_path):
	
	a=pickle.loads(open("training_model", "rb").read())
	
	face_encodings = []
	face_names = []
	
	img=fr.load_image_file(image_path)
	try:
		face_encodings = fr.face_encodings(img)[0]
		matches = fr.compare_faces(a["encodings"], face_encodings)
		face_names.append("unknown")
				
		if True in matches:
		    first_match_index = matches.index(True)
		    name = a["names"][first_match_index]
	    	face_names.append(name)
	    	return name

    	#return(face_names[-1])	    
   		
	except:
		message="face not found"
		return message
	
	
# error while  llast name return	
