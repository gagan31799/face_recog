from rest_framework import serializers
from .models import employee,record

class recordSerializer(serializers.ModelSerializer):
	class Meta:
		model=record
		fields='__all__'