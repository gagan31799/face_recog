from __future__ import unicode_literals

from django.db import models
from datetime import datetime
import sys

sys.dont_write_bytecode = True
# Create your models here.

class employee(models.Model):
	sr_id = models.AutoField(primary_key=True)
	employee_id = models.CharField(max_length=30)
	name = models.CharField(max_length=30)
	profile_image = models.ImageField(upload_to='photos/known/', default='photos/known/no-img.jpg',blank=True, null=True)
	date = models.DateTimeField(datetime.now())

	def __str__(self):
	    	return str(self.sr_id)


class record(models.Model):	
    sr_id=models.AutoField(primary_key=True)
    employee_id = models.CharField(max_length=80, default="unknown")
    name = models.CharField(max_length=30,default="unknown")
    profile_image = models.ImageField(upload_to='photos/unknown/',blank=True, null=True)
    date=models.DateTimeField(datetime.now())

    def __str__(self):
        return str(self.sr_id)
