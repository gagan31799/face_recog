
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import employee,record
from .serializers import recordSerializer
from rest_framework import status

class recordList(APIView):

	def get(self,request):
		print("hello")
		record1=record.objects.all()
		serializer=recordSerializer(record1,many=True)
		return Response(serializer.data)


	def post(self,request):
		pass
		# serializer = SnippetSerializer(data=request.data)
  #       if serializer.is_valid():
  #           serializer.save()
